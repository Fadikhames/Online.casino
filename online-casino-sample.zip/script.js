
function login() {
  alert("Login button clicked!");
}

function signup() {
  alert("Sign Up button clicked!");
}
